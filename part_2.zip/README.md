# Golang Blockchain

### In this tutorial, we look at how we can build a blockchain with Golang. 

## Run `go run main.go` to run the app, run `go build main.go` to build an executable file.

### Check out the Youtube Tutorial for this [Go Program](https://www.youtube.com/embed/aE4eDTUAE70). Here is our [Youtube Channel](https://www.youtube.com/channel/UCYqCZOwHbnPwyjawKfE21wg) Subscribe for more content.

### Check out our blog at [tensor-programming.com](http://tensor-programming.com/).

### Our [Twitter](https://twitter.com/TensorProgram), our [facebook](https://www.facebook.com/Tensor-Programming-1197847143611799/) and our [Steemit](https://steemit.com/@tensor).
